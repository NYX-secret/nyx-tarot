# NYX — 静かな夜に、自分と向き合う。

3Dタロット占いWebアプリ。ビルド不要の静的サイト(HTML / CSS / JavaScript のみ)なので、GitHub Pages にそのまま公開できます。

- 占い方法: ワンオラクル / スリーカード / ケルト十字
- 大アルカナ22枚(固有イラスト、正位置・逆位置、恋愛・仕事・人生の解釈つき)
- CSS 3D によるカード召喚・シャッフル・フリップ・浮遊
- スマホ対応(ケルト十字はモバイルで重ならない配置)、`prefers-reduced-motion` 対応、低スペック端末では演出を軽量化
- 外部ライブラリなし(フォントのみ Google Fonts、読み込めなくても代替フォントで動作)

## GitHub Pages で公開する

1. このフォルダの中身(`index.html`, `css/`, `js/`, `favicon.svg`, `.nojekyll`)をリポジトリのルートに置いて push
2. リポジトリの **Settings → Pages → Build and deployment**
   - Source: **Deploy from a branch**
   - Branch: **main** / **/(root)**
3. 数分後、`https://<ユーザー名>.github.io/<リポジトリ名>/` で公開されます

パスはすべて相対パスなので、サブパスでもカスタムドメインでも設定変更は不要です。URL直下のページのみ(ルーティングなし)のため、再読み込みで404にもなりません。

## ローカルで試す

`index.html` をブラウザで開くだけで動きます。サーバーを使う場合:

```bash
python3 -m http.server 8000   # http://localhost:8000
```

## 構成

```
index.html        画面の骨組み(7画面)
css/style.css     デザイン(Midnight Navy × Champagne Gold)と3D演出
js/data.js        カード22枚のデータ・スプレッド定義(UIから分離)
js/art.js         カード表面・裏面のSVGイラスト
js/app.js         画面遷移・シャッフル・抽選・正逆位置・リーディング生成
```

## 拡張(小アルカナ56枚など)

- `js/data.js` の `CARDS` にカードを追記(`arcana: 'minor'`, `suit` などを付与)
- `js/art.js` の `MOTIF` に図柄を追加
- `app.js` の山札は `CARDS` 全体から作られるため、追加するだけで78枚構成になります
