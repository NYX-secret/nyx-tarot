/* NYX — アプリ本体(フレームワーク不要・GitHub Pagesにそのまま置ける) */
(function () {
  'use strict';
  var CARDS = NYX_DATA.CARDS, SPREADS = NYX_DATA.SPREADS;
  var $ = function (s, el) { return (el || document).querySelector(s); };
  var el = function (tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };

  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var lowSpec = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 2);
  if (lowSpec || reduce) document.body.classList.add('lite');

  var state = { spread: null, deck: [], picked: [], flipped: 0 };
  var timers = [];
  function later(fn, ms) { var t = setTimeout(fn, reduce ? Math.min(ms, 50) : ms); timers.push(t); return t; }
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }

  /* ---------- 乱数(暗号論的乱数が使えれば使う) ---------- */
  function rnd() {
    if (window.crypto && crypto.getRandomValues) { var a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] / 4294967296; }
    return Math.random();
  }
  function shuffle(arr) { var a = arr.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ---------- 画面遷移 ---------- */
  var screens = { opening: '#s-opening', method: '#s-method', shuffle: '#s-shuffle', select: '#s-select', reveal: '#s-reveal', result: '#s-result' };
  var labels = { opening: '', method: '01 / 占い方法', shuffle: '02 / シャッフル', select: '03 / カード選択', reveal: '04 / Reveal', result: '05 / 結果' };
  var current = null;
  function go(name) {
    Object.keys(screens).forEach(function (k) { $(screens[k]).classList.toggle('active', k === name); });
    current = name;
    $('#topbar').hidden = name === 'opening';
    $('#step-label').textContent = labels[name];
    if (name === 'result') $('#s-result').scrollTop = 0;
    requestAnimationFrame(layoutAll);
  }

  /* ---------- 占い方法 ---------- */
  function buildMethods() {
    var box = $('#methods');
    ['one', 'three', 'celtic'].forEach(function (id, i) {
      var s = SPREADS[id];
      var b = el('button', 'method',
        '<span class="n">0' + (i + 1) + '</span><span class="name">' + s.name + '</span><span class="en">' + s.en + '</span>' +
        '<p class="desc">' + s.desc + '</p><span class="count">' + s.count + ' CARD' + (s.count > 1 ? 'S' : '') + '</span>');
      b.addEventListener('click', function () { startReading(id); });
      box.appendChild(b);
    });
  }

  /* ---------- 召喚・シャッフル ---------- */
  function startReading(id) {
    clearTimers();
    state.spread = SPREADS[id];
    state.picked = []; state.flipped = 0;
    // 山札:全カードをシャッフルし、各カードの正逆をここで確定
    state.deck = shuffle(CARDS).map(function (c) { return { card: c, rev: rnd() < 0.5 }; });

    var deck = $('#deck'); deck.className = 'deck'; deck.innerHTML = '';
    var n = lowSpec ? 6 : 10;
    for (var i = 0; i < n; i++) {
      var d = el('div', 'dc'); d.style.setProperty('--i', i); d.style.setProperty('--dir', i % 2 ? 1 : -1);
      d.innerHTML = '<img alt="" src="' + NYX_ART.back() + '">';
      deck.appendChild(d);
    }
    $('#shuffle-caption').textContent = 'カードを呼び寄せています';
    go('shuffle');
    later(function () { deck.classList.add('summon'); }, 500);
    later(function () { $('#shuffle-caption').textContent = 'ゆっくりと、シャッフルしています'; deck.classList.remove('summon'); deck.classList.add('shuffle'); }, 2600);
    later(function () { $('#shuffle-caption').textContent = '深呼吸をして、心を静めて。'; }, 5400);
    later(function () { startSelect(); }, 6600);
  }

  /* ---------- カード選択 ---------- */
  function startSelect() {
    var s = state.spread;
    $('#select-eyebrow').textContent = s.en;
    $('#select-title').textContent = s.name;
    var fan = $('#fan'); fan.innerHTML = '';
    state.deck.forEach(function (d, i) {
      var b = el('button', 'pick');
      b.setAttribute('aria-label', 'カード ' + (i + 1));
      b.innerHTML = '<span class="face"><img alt="" draggable="false" src="' + NYX_ART.back() + '"></span><span class="badge"></span>';
      b.addEventListener('click', function () { pick(i, b); });
      b.style.opacity = 0; b.style.transform = 'translateY(40px)';
      fan.appendChild(b);
      later(function () { b.style.opacity = ''; b.style.transform = ''; }, 350 + i * 35);
    });
    updateHint();
    go('select');
  }
  function updateHint() {
    var s = state.spread, i = state.picked.length;
    $('#select-hint').textContent = i < s.count
      ? (s.count > 1 ? '「' + s.positions[i].key + '」のカードを選んでください(' + (i + 1) + ' / ' + s.count + ')' : '心に引っかかるカードを、ひとつ選んでください。')
      : '選び終えました。カードを並べます。';
  }
  function pick(i, btn) {
    var s = state.spread;
    if (btn.classList.contains('taken') || state.picked.length >= s.count) return;
    state.picked.push(state.deck[i]);
    btn.classList.add('taken');
    btn.querySelector('.badge').textContent = state.picked.length;
    updateHint();
    if (state.picked.length === s.count) later(startReveal, 1100);
  }
  function layoutFan() {
    var fan = $('#fan'), items = fan.children, n = items.length; if (!n) return;
    var W = fan.parentNode.clientWidth;
    var availH = window.innerHeight - 230;
    var rows = W < 520 ? 3 : (W < 900 ? 2 : 1);
    var perRow = Math.ceil(n / rows);
    var cw = Math.min(112, W / 4.6);
    var ch = cw * 1.7;
    // 高さに収まるよう調整
    var rowH = ch * 0.5;
    while (rows * rowH + ch * 0.5 > availH && cw > 56) { cw -= 4; ch = cw * 1.7; rowH = ch * 0.5; }
    var step = Math.min(cw * 0.62, (W - cw) / (perRow - 1));
    var totalW = cw + step * (perRow - 1);
    fan.style.setProperty('--cw', cw + 'px');
    fan.style.height = (rows * rowH + ch * 0.55) + 'px';
    for (var i = 0; i < n; i++) {
      var row = Math.floor(i / perRow), col = i % perRow;
      var inRow = Math.min(perRow, n - row * perRow);
      var rowW = cw + step * (inRow - 1);
      var t = inRow > 1 ? col / (inRow - 1) : 0.5;
      var arc = -Math.sin(Math.PI * t) * Math.min(14, ch * 0.08);
      items[i].style.left = ((W - rowW) / 2 + step * col) + 'px';
      items[i].style.top = (row * rowH + arc + 14) + 'px';
      items[i].style.zIndex = col + 1;
    }
  }

  /* ---------- Reveal ---------- */
  var CELTIC_POS = [[1, 1.5], [1, 1.5], [1, 0.5], [1, 2.5], [0, 1.5], [2, 1.5], [3.45, 3], [3.45, 2], [3.45, 1], [3.45, 0]];

  function startReveal() {
    var s = state.spread, table = $('#table');
    table.innerHTML = ''; state.flipped = 0;
    $('#reveal-status').innerHTML = '';
    $('#btn-result').disabled = true; $('#btn-openall').disabled = false;
    state.picked.forEach(function (p, i) {
      var slot = el('div', 'slot');
      slot.dataset.i = i;
      var card = el('button', 'card3d float deal');
      card.style.setProperty('--i', i); card.style.setProperty('--fd', (i * 0.7) + 's');
      card.style.setProperty('--rot', p.rev ? '180deg' : '0deg');
      card.setAttribute('aria-label', s.positions[i].key + ' のカードを開く');
      card.innerHTML =
        '<span class="orient"><span class="flipper">' +
        '<span class="face back"><img alt="" draggable="false" src="' + NYX_ART.back() + '"></span>' +
        '<span class="face front"><img alt="' + p.card.ja + ' ' + p.card.en + (p.rev ? ' 逆位置' : ' 正位置') + '" draggable="false" src="' + NYX_ART.front(p.card) + '"></span>' +
        '</span></span>';
      card.addEventListener('click', function () { flip(i); });
      var pos = el('div', 'pos', (s.count > 1 ? '<b>' + (i + 1) + '</b>' : '') + s.positions[i].key);
      slot.appendChild(card);
      if (s.count > 1) slot.insertBefore(el('span', 'num', String(i + 1)), card);
      slot.appendChild(pos);
      table.appendChild(slot);
    });
    $('#reveal-hint').textContent = s.count === 1 ? 'カードをタップして、開きます。' : 'カードをタップして、ひとつずつ開きます。';
    go('reveal');
  }

  function flip(i) {
    var slot = $('#table').children[i]; if (!slot) return;
    var card = slot.querySelector('.card3d');
    if (card.classList.contains('flipped')) { showStatus(i); return; }
    card.classList.remove('float', 'deal');
    card.classList.add('flipped', 'lift');
    state.flipped++;
    showStatus(i);
    if (state.flipped === state.picked.length) { $('#btn-result').disabled = false; $('#btn-openall').disabled = true; }
  }
  function showStatus(i) {
    var p = state.picked[i], pos = state.spread.positions[i];
    $('#reveal-status').innerHTML = '<span class="t">' + (state.spread.count > 1 ? (i + 1) + '. ' + pos.key + ' — ' : '') + '</span>' +
      p.card.ja + ' <span class="t">' + p.card.en + '</span>(' + (p.rev ? '逆位置' : '正位置') + ')';
  }
  function openAll() {
    var k = 0;
    state.picked.forEach(function (_, i) {
      var c = $('#table').children[i].querySelector('.card3d');
      if (!c.classList.contains('flipped')) { later(function () { flip(i); }, 250 + (k++) * 520); }
    });
  }

  function layoutTable() {
    var table = $('#table'), s = state.spread; if (!s || !table.children.length) return;
    var n = table.children.length;
    var W = table.clientWidth, H = table.clientHeight;
    var slots = table.children, i, cw;
    var celticAbs = s.id === 'celtic' && W >= 820;
    table.classList.toggle('abs', celticAbs);
    table.classList.toggle('flow', !celticAbs && s.id === 'celtic');
    for (i = 0; i < n; i++) { slots[i].style.left = slots[i].style.top = ''; slots[i].style.transform = ''; slots[i].style.zIndex = ''; }
    if (celticAbs) {
      cw = Math.max(62, Math.min(W / 5.2, (H - 24) / 7.2, 150));
      var ch = cw * 1.7, gx = cw * 1.2, gy = ch * 1.04;
      var totalW = 3.45 * gx + cw, totalH = 3 * gy + ch;
      var offX = (W - totalW) / 2, offY = 12 + Math.max(0, (H - 24 - totalH) / 2);
      table.style.alignItems = 'flex-start';
      for (i = 0; i < n; i++) {
        var p = CELTIC_POS[i];
        slots[i].style.left = (offX + p[0] * gx) + 'px';
        slots[i].style.top = (offY + p[1] * gy) + 'px';
        slots[i].style.zIndex = i === 1 ? 6 : 1;
        if (i === 1) slots[i].style.transform = 'rotate(90deg)';
      }
      table.style.overflowY = totalH + 24 > H ? 'auto' : 'visible';
      var sp = document.createElement('div'); sp.style.cssText = 'position:absolute;left:0;top:' + (totalH + offY) + 'px;width:1px;height:1px'; // スクロール領域確保
      var old = table.querySelector('.sp'); if (old) old.remove(); sp.className = 'sp'; table.appendChild(sp);
    } else {
      table.style.alignItems = ''; table.style.overflowY = '';
      var oldsp = table.querySelector('.sp'); if (oldsp) oldsp.remove();
      if (s.id === 'one') cw = Math.max(110, Math.min(220, W * 0.55, (H - 40) * 200 / 340));
      else if (s.id === 'three') cw = Math.max(76, Math.min((W - 28) / 3 - 2, 190, (H - 50) * 200 / 340));
      else cw = Math.max(72, Math.min((W - 28) / 3 - 6, 120));
      table.style.gap = s.id === 'three' ? '0 14px' : '';
    }
    table.style.setProperty('--cw', cw + 'px');
  }

  /* ---------- 結果 ---------- */
  function ori(p) { return p.rev ? '逆位置' : '正位置'; }
  function key(p) { return p.rev ? 'rev' : 'up'; }

  function readingOne(a) {
    var c = a.card, out = [];
    out.push('今のあなたに届いたのは「' + c.ja + '」(' + ori(a) + ')。' + (a.rev
      ? '「' + c.keywords[0] + '」のテーマが、いまは少し内側に向いているようです。結論を急がず、立ち止まって確かめるためのヒントとして受け取ってみてください。'
      : '「' + c.keywords[0] + '」と「' + c.keywords[1] + '」が、いまの気持ちの輪郭をそっと照らしています。'));
    out.push((a.rev ? c.reversed : c.upright));
    out.push('今日は「' + c.keywords[2] + '」という言葉を、頭の片隅に置いて過ごしてみてください。未来を決めるものではなく、ご自身を見つめ直すための小さな手がかりです。');
    return out;
  }
  function readingThree(P) {
    var a = P[0], b = P[1], c = P[2], out = [];
    out.push('過去には「' + a.card.ja + '」(' + ori(a) + ')。' + a.card.keywords[0] + 'をめぐる出来事が、' + (a.rev ? 'まだ整理しきれない余韻として' : 'いまの土台として') + '残っているようです。');
    out.push('現在は「' + b.card.ja + '」(' + ori(b) + ')。いま前面にあるのは' + b.card.keywords[0] + 'というテーマで、' + (b.rev ? '見直しや調整の視点' : '素直に向き合う姿勢') + 'が助けになりそうです。');
    out.push('未来には「' + c.card.ja + '」(' + ori(c) + ')。この流れの先に' + c.card.keywords[0] + 'が見えてきます。' + (c.rev ? '気になる点を先に整えておくと、よりなめらかに進めるかもしれません。' : 'いまの歩みを大切にすれば、自然に近づいていける方向です。'));
    var rc = P.filter(function (x) { return x.rev; }).length;
    out.push(rc === 0 ? '三枚とも正位置で、流れが素直に外へ向かっている配置です。' : rc === 3 ? '三枚とも逆位置で、いまは外へ動くより、内側を整える時間が大切だと読めます。' : '正位置と逆位置が混ざり、前に進む力と、立ち止まって見直す視点の両方が必要な流れです。');
    out.push('過去から未来へ通して見ると、「' + a.card.keywords[0] + '」→「' + b.card.keywords[0] + '」→「' + c.card.keywords[0] + '」という変化の道筋が見えてきます。未来は決まったものではなく、これからの選び方で変わっていきます。');
    return out;
  }
  function readingCeltic(P) {
    var k = function (i) { return P[i].card.keywords[0]; }, j = function (i) { return P[i].card.ja; }, out = [];
    out.push('状況の中心には「' + j(0) + '」(' + ori(P[0]) + ')。そこに交差する「' + j(1) + '」(' + ori(P[1]) + ')は、' + k(1) + 'に関わる課題を示しています。' + (P[1].rev ? '課題は、見方次第で和らぐ余地があるようです。' : '正面から向き合うことで、見えてくるものがありそうです。'));
    out.push('意識では「' + k(2) + '」を、無意識では「' + k(3) + '」を抱えているようです。' + (P[2].rev !== P[3].rev ? '二つの層の向きに少しずれがあるため、本音を言葉にしてみると整理しやすくなります。' : '二つの層は、おおむね同じ方向を向いています。'));
    out.push('過去の「' + j(4) + '」が現在に影響し、近い未来には「' + j(5) + '」(' + ori(P[5]) + ')の流れが訪れそうです。' + (P[5].rev ? 'その前に、気になる点を整えておくと安心です。' : '変化を落ち着いて受け止める準備をしておきましょう。'));
    out.push('あなた自身の姿勢は「' + j(6) + '」、周囲の状況は「' + j(7) + '」で表されています。内なる姿勢と環境との間に、' + (P[6].rev === P[7].rev ? '大きな食い違いは見られません。' : '少し温度差があるかもしれません。'));
    out.push('願望と恐れには「' + j(8) + '」(' + ori(P[8]) + ')。そして最終結果の「' + j(9) + '」(' + ori(P[9]) + ')は、' + k(9) + 'を軸にした到達点の一例です。' + (P[9].rev ? 'ただし逆位置は、立ち止まって見直す余地を示すサインでもあります。' : 'これまでの読み解きが、穏やかにまとまっていく方向です。'));
    var rc = P.filter(function (x) { return x.rev; }).length;
    out.push(rc >= 7 ? '10枚中' + rc + '枚が逆位置で、外に動くよりも、内省して整える色合いの濃いスプレッドです。' : rc <= 3 ? '10枚中' + rc + '枚が逆位置で、素直に進める力の強いスプレッドです。' : '10枚中' + rc + '枚が逆位置で、進む力と見直す視点がバランスよく並んでいます。');
    out.push('これは未来を断定するものではありません。気になった言葉や場面をヒントに、ご自身の気持ちを静かに確かめてみてください。');
    return out;
  }

  function showResult() {
    var s = state.spread, root = $('#result'); root.innerHTML = '';
    root.appendChild(el('div', 'head', '<p class="eyebrow">' + s.en + '</p><h2 class="title" style="margin:0">' + s.name + ' のリーディング</h2>'));
    state.picked.forEach(function (p, i) {
      var c = p.card, pos = s.positions[i], k = key(p);
      var box = el('article', 'rcard',
        '<div class="thumb"><div class="orient" style="--rot:' + (p.rev ? '180deg' : '0deg') + '"><img alt="' + c.ja + '" src="' + NYX_ART.front(c) + '"></div></div>' +
        '<div><div class="pos">' + (s.count > 1 ? (i + 1) + ' — ' : '') + pos.key + '</div>' +
        '<h3>' + c.ja + '<span class="tag ' + (p.rev ? 'rev' : '') + '">' + ori(p) + '</span></h3>' +
        '<div class="en">' + c.en + '</div>' +
        '<div class="kws">' + c.keywords.map(function (w) { return '<span>' + w + '</span>'; }).join('') + '</div>' +
        (s.count > 1 ? '<p class="pdesc">' + pos.desc + '</p>' : '') +
        '<p>' + c.base + '</p><p>' + (p.rev ? c.reversed : c.upright) + '</p>' +
        '<dl><div><dt>恋愛</dt><dd>' + c.love[k] + '</dd></div><div><dt>仕事</dt><dd>' + c.work[k] + '</dd></div><div><dt>人生・自己成長</dt><dd>' + c.life[k] + '</dd></div></dl></div>');
      root.appendChild(box);
    });
    var paras = s.id === 'one' ? readingOne(state.picked[0]) : s.id === 'three' ? readingThree(state.picked) : readingCeltic(state.picked);
    var ov = el('section', 'overall', '<h3>' + (s.count === 1 ? 'メッセージ' : '総合リーディング') + '</h3>' + paras.map(function (t) { return '<p>' + t + '</p>'; }).join(''));
    root.appendChild(ov);
    root.appendChild(el('p', 'note', 'この結果は未来を断定するものではなく、自分を見つめ直すためのヒントです。'));
    var act = el('div', 'actions');
    var again = el('button', 'btn', 'もう一度占う'), home = el('button', 'btn ghost', '最初に戻る');
    again.addEventListener('click', function () { clearTimers(); go('method'); });
    home.addEventListener('click', toHome);
    act.appendChild(again); act.appendChild(home); root.appendChild(act);
    go('result');
  }

  function toHome() { clearTimers(); go('opening'); }

  function layoutAll() { if (current === 'select') layoutFan(); if (current === 'reveal') layoutTable(); }
  var rt; window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(layoutAll, 120); });
  window.addEventListener('orientationchange', function () { setTimeout(layoutAll, 250); });

  $('#btn-start').addEventListener('click', function () { go('method'); });
  $('#btn-home').addEventListener('click', toHome);
  $('#btn-result').addEventListener('click', showResult);
  $('#btn-openall').addEventListener('click', openAll);
  $('#s-shuffle').addEventListener('click', function () { /* タップで先へ */ if (current === 'shuffle') { clearTimers(); startSelect(); } });

  buildMethods();
  go('opening');
  window.NYX_DEBUG = { state: state };
})();
