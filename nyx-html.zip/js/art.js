/* NYX — カード意匠。表面22枚のSVGと裏面。外部画像なし(data URIで配布)。 */
(function () {
  var G = '#c9b27c', B = '#7d8798', W = '#f1ede4', N = '#0b1020', N2 = '#16203a';
  var ROMAN = ['0', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX', 'XXI'];

  function c(x, y, r, o) { o = o || {}; return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + (o.f || 'none') + '" stroke="' + (o.s || G) + '" stroke-width="' + (o.w || 1.2) + '" opacity="' + (o.o || 1) + '"/>'; }
  function l(x1, y1, x2, y2, o) { o = o || {}; return '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" stroke="' + (o.s || G) + '" stroke-width="' + (o.w || 1.2) + '" stroke-linecap="round" opacity="' + (o.o || 1) + '"/>'; }
  function p(d, o) { o = o || {}; return '<path d="' + d + '" fill="' + (o.f || 'none') + '" stroke="' + (o.s || G) + '" stroke-width="' + (o.w || 1.2) + '" stroke-linecap="round" stroke-linejoin="round" opacity="' + (o.o || 1) + '"/>'; }
  function r(x, y, w, h, o) { o = o || {}; return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + (o.f || 'none') + '" stroke="' + (o.s || G) + '" stroke-width="' + (o.w || 1.2) + '" opacity="' + (o.o || 1) + '"/>'; }
  function rays(x, y, r1, r2, n, o) {
    var s = '';
    for (var i = 0; i < n; i++) { var a = (Math.PI * 2 * i) / n; s += l(x + Math.cos(a) * r1, y + Math.sin(a) * r1, x + Math.cos(a) * r2, y + Math.sin(a) * r2, o); }
    return s;
  }
  function star(x, y, R, n, ro) { // n 角の星
    var pts = [];
    for (var i = 0; i < n * 2; i++) { var a = (Math.PI * i) / n - Math.PI / 2, rr = i % 2 ? R * (ro || 0.42) : R; pts.push((x + Math.cos(a) * rr).toFixed(1) + ',' + (y + Math.sin(a) * rr).toFixed(1)); }
    return '<polygon points="' + pts.join(' ') + '" fill="none" stroke="' + G + '" stroke-width="1.1" stroke-linejoin="round"/>';
  }
  function moon(x, y, R, o) { return p('M' + x + ' ' + (y - R) + 'A' + R + ' ' + R + ' 0 1 0 ' + x + ' ' + (y + R) + 'A' + (R * 0.72) + ' ' + R + ' 0 1 1 ' + x + ' ' + (y - R) + 'Z', o); }
  function inf(x, y, w) { return p('M' + x + ' ' + y + 'C' + (x + w * 0.4) + ' ' + (y - w * 0.55) + ' ' + (x + w) + ' ' + (y - w * 0.55) + ' ' + (x + w) + ' ' + y + 'C' + (x + w) + ' ' + (y + w * 0.55) + ' ' + (x + w * 0.4) + ' ' + (y + w * 0.55) + ' ' + x + ' ' + y + 'Z', { w: 1.3 }); }
  function person(x, y, s, o) { // 簡素な人物(頭+身体の三角)
    s = s || 1;
    return c(x, y, 5 * s, o) + p('M' + x + ' ' + (y + 5 * s) + 'L' + (x - 9 * s) + ' ' + (y + 34 * s) + 'L' + (x + 9 * s) + ' ' + (y + 34 * s) + 'Z', o);
  }
  function hill(y, a) { return p('M20 ' + y + 'L' + (60) + ' ' + (y - a) + 'L' + 100 + ' ' + y + 'L' + 140 + ' ' + (y - a * 1.3) + 'L180 ' + y, { s: B, w: 1 }); }

  var MOTIF = {
    fool: function () { return c(100, 100, 18) + rays(100, 100, 22, 30, 12, { w: 0.9 }) + hill(250, 36) + p('M70 250L95 205L130 215', { s: B, w: 1, o: 0.8 }) + person(100, 150, 1) + l(112, 168, 132, 160) + l(132, 160, 138, 130, { s: B }) + c(138, 126, 4, { s: B }) + p('M60 262Q100 252 150 268', { s: B, o: 0.7 }); },
    magician: function () { return inf(76, 90, 48) + l(100, 120, 100, 160) + person(100, 168, 1) + r(48, 226, 104, 10, { w: 1 }) + c(66, 216, 6) + r(94, 210, 12, 12) + p('M126 222L134 208L142 222Z') + p('M158 216l-8-8 8-8 8 8Z', { w: 1 }) + l(60, 150, 140, 150, { s: B, o: 0.5 }); },
    'high-priestess': function () { return r(38, 90, 16, 150, { w: 1.2 }) + r(146, 90, 16, 150, { w: 1.2 }) + l(46, 110, 46, 230, { s: B, o: 0.5 }) + l(154, 110, 154, 230, { s: B, o: 0.5 }) + moon(100, 125, 18) + c(100, 150, 4) + p('M70 240L84 170L116 170L130 240Z', { w: 1.2 }) + p('M66 100Q100 70 134 100', { s: B, w: 1 }) + l(70, 240, 130, 240); },
    empress: function () { var s = ''; for (var i = 0; i < 12; i++) { var a = (Math.PI * 2 * i) / 12; s += star(100 + Math.cos(a) * 34, 120 + Math.sin(a) * 34, 4, 5); } return s + c(100, 120, 20) + p('M100 140L100 176M88 160L112 160', { w: 1.3 }) + c(100, 192, 10) + p('M60 262Q70 215 78 240M80 262Q88 205 96 240M140 262Q130 215 122 240M120 262Q112 205 104 240', { s: B, w: 1 }) + l(40, 262, 160, 262, { s: B }); },
    emperor: function () { return r(62, 100, 76, 130, { w: 1.3 }) + r(76, 130, 48, 100, { w: 1, s: B }) + p('M76 100Q60 82 72 70M124 100Q140 82 128 70', { w: 1.2 }) + c(100, 120, 12) + l(150, 100, 150, 245) + c(150, 96, 6) + l(144, 142, 156, 142, { s: B }) + l(50, 240, 150, 240) + p('M82 230L82 170M118 230L118 170', { s: B, o: 0.5 }); },
    hierophant: function () { return l(100, 70, 100, 200, { w: 1.4 }) + l(84, 92, 116, 92) + l(78, 112, 122, 112) + l(72, 132, 128, 132) + p('M70 200Q100 184 130 200', { w: 1 }) + person(60, 215, 0.7, { s: B }) + person(140, 215, 0.7, { s: B }) + p('M58 150l8 0 0-14M142 150l-8 0 0-14', { s: B, w: 1 }) + l(40, 262, 160, 262, { s: B }); },
    lovers: function () { return c(100, 98, 22, { w: 1.3 }) + rays(100, 98, 27, 36, 16, { w: 0.9 }) + c(76, 190, 26, { w: 1.2 }) + c(124, 190, 26, { w: 1.2, s: W, o: 0.8 }) + p('M100 160L100 220', { s: B, o: 0.6 }) + p('M54 262Q100 232 146 262', { s: B, w: 1 }) + star(100, 98, 8, 6); },
    chariot: function () { return r(62, 160, 76, 54, { w: 1.3 }) + c(76, 230, 14) + c(124, 230, 14) + c(76, 230, 3, { f: G }) + c(124, 230, 3, { f: G }) + p('M62 160L62 110M138 160L138 110M54 110L146 110L136 92L64 92Z', { w: 1.1 }) + star(80, 101, 4, 5) + star(100, 101, 4, 5) + star(120, 101, 4, 5) + person(100, 138, 0.7) + p('M26 214Q40 190 56 210L40 228Z', { s: B }) + p('M174 214Q160 190 144 210L160 228Z', { s: W, o: 0.7 }); },
    strength: function () { return inf(76, 80, 48) + c(100, 160, 16) + p('M100 176Q64 190 70 230Q100 250 134 232Q142 200 112 178', { w: 1.2 }) + p('M62 150Q70 120 100 130M138 150Q130 120 100 130', { s: B, w: 1 }) + l(48, 262, 152, 262, { s: B }) + p('M60 196Q40 226 62 246', { s: B, w: 1 }); },
    hermit: function () { return p('M20 268L70 180L100 220L136 150L184 268Z', { s: B, w: 1 }) + person(84, 130, 1) + l(122, 118, 122, 232, { w: 1.3 }) + r(112, 96, 20, 22, { w: 1.1 }) + star(122, 107, 7, 6) + rays(122, 107, 14, 20, 8, { o: 0.35, w: 0.8 }); },
    wheel: function () { return c(100, 168, 62, { w: 1.4 }) + c(100, 168, 42, { w: 1 }) + c(100, 168, 8, { f: G }) + rays(100, 168, 8, 62, 8, { w: 1 }) + c(100, 98, 4, { f: G }) + c(162, 168, 4, { f: G }) + c(100, 238, 4, { f: G }) + c(38, 168, 4, { f: G }) + p('M80 62Q100 50 120 62', { s: B, w: 1 }); },
    justice: function () { return l(100, 74, 100, 258, { w: 1.5 }) + l(54, 110, 146, 110, { w: 1.3 }) + p('M54 110L38 160L70 160Z', { w: 1.1 }) + p('M146 110L130 160L162 160Z', { w: 1.1 }) + c(100, 100, 7) + p('M94 258L100 240L106 258', { w: 1.2 }) + l(84, 208, 116, 208, { s: B }) + c(100, 74, 4, { f: G }); },
    'hanged-man': function () { return p('M44 76L156 76', { w: 1.5 }) + l(44, 76, 44, 250, { w: 1.5 }) + l(156, 76, 156, 250, { w: 1.5 }) + l(100, 76, 100, 112) + c(100, 176, 24, { s: B, w: 0.9, o: 0.7 }) + p('M100 112L90 150L110 150Z', { w: 1.1 }) + l(100, 150, 100, 174) + l(100, 174, 88, 194, { s: B }) + l(100, 174, 114, 194, { s: B }) + c(100, 202, 6) + l(100, 112, 100, 150, { o: 0 }); },
    death: function () { return l(100, 72, 100, 250, { w: 1.4 }) + p('M100 90L152 100L100 124Z', { w: 1.1 }) + c(100, 80, 5) + p('M30 250L30 170L56 170L56 250M144 250L144 170L170 170L170 250', { s: B, w: 1 }) + c(100, 214, 16, { w: 1.2 }) + rays(100, 214, 20, 28, 12, { w: 0.9 }) + p('M30 250L170 250', { s: B }) + p('M64 160Q84 140 100 150Q116 140 136 160', { s: B, w: 0.9 }); },
    temperance: function () { return p('M52 90Q100 56 148 90', { s: B, w: 1 }) + p('M60 140L72 140L68 170L64 170Z', { w: 1.1 }) + p('M128 180L140 180L136 210L132 210Z', { w: 1.1 }) + p('M68 154Q100 150 100 168Q100 186 132 190', { w: 1.1 }) + p('M70 172Q100 168 100 186Q100 204 130 206', { w: 1.1, o: 0.55 }) + p('M100 224L114 248L86 248Z', { s: B }) + r(88, 232, 24, 24, { s: B, o: 0.6 }) + p('M30 262Q100 240 170 262', { s: B, w: 1 }) + c(100, 100, 6, { f: G }); },
    devil: function () { var pts = [], i; for (i = 0; i < 5; i++) { var a = (Math.PI * 2 * i) / 5 + Math.PI / 2; pts.push([100 + Math.cos(a) * 36, 118 + Math.sin(a) * 36]); } var order = [0, 2, 4, 1, 3, 0], d = 'M'; order.forEach(function (k, j) { d += (j ? 'L' : '') + pts[k][0].toFixed(1) + ' ' + pts[k][1].toFixed(1); }); return c(100, 118, 40, { s: B, w: 0.9 }) + p(d, { w: 1.2 }) + p('M70 84Q56 66 70 56M130 84Q144 66 130 56', { w: 1.2 }) + r(76, 190, 48, 22, { w: 1.2 }) + person(60, 226, 0.7, { s: B }) + person(140, 226, 0.7, { s: B }) + p('M66 232Q82 214 88 212M134 232Q118 214 112 212', { s: B, w: 0.9, o: 0.7 }); },
    tower: function () { return r(78, 130, 44, 120, { w: 1.3 }) + p('M72 130L72 108L84 116L92 100L100 116L108 100L116 116L128 108L128 130', { w: 1.2 }) + p('M104 70L92 108L108 108L96 150', { w: 1.5, s: W }) + p('M40 210L52 190M156 190L164 214M48 150L56 134M150 140L160 124', { s: B, w: 1 }) + c(42, 220, 3, { s: B }) + c(160, 226, 3, { s: B }) + c(52, 170, 2, { s: B }) + l(88, 250, 88, 170, { s: B, o: 0.5 }) + l(30, 250, 170, 250, { s: B }); },
    star: function () { var s = star(100, 124, 40, 8, 0.4) + star(100, 124, 22, 8, 0.4), pos = [[44, 76], [156, 76], [30, 138], [170, 138], [48, 190], [152, 190], [100, 62]]; pos.forEach(function (q) { s += star(q[0], q[1], 7, 5); }); return s + p('M70 232Q85 218 100 232Q115 246 130 232', { s: B, w: 1.1 }) + p('M72 248Q86 236 100 248Q114 260 128 248', { s: B, w: 1, o: 0.6 }); },
    moon: function () { return c(100, 104, 30, { w: 1.2 }) + moon(100, 104, 20) + rays(100, 104, 34, 44, 16, { w: 0.8, o: 0.6 }) + r(36, 190, 24, 60, { w: 1.1 }) + r(140, 190, 24, 60, { w: 1.1 }) + p('M100 270Q120 240 92 220Q72 204 100 190', { s: B, w: 1.2 }) + p('M70 258L76 244L82 258M118 258L124 244L130 258', { s: B, w: 1 }) + c(100, 176, 3, { f: G }); },
    sun: function () { return c(100, 130, 32, { w: 1.5 }) + c(100, 130, 22, { w: 1, o: 0.6 }) + rays(100, 130, 40, 58, 20, { w: 1 }) + c(100, 220, 7) + p('M100 227L92 248L108 248Z') + l(40, 262, 160, 262, { s: B }) + p('M50 262L50 214M150 262L150 214', { s: B, w: 1 }) + c(50, 208, 7, { s: B }) + c(150, 208, 7, { s: B }); },
    judgement: function () { return p('M70 80L130 100L130 82Z', { w: 1.2 }) + p('M130 100Q150 108 148 118', { w: 1.1 }) + rays(100, 66, 6, 14, 8, { o: 0.5, w: 0.8 }) + r(32, 220, 38, 30, { s: B, w: 1 }) + r(81, 220, 38, 30, { s: B, w: 1 }) + r(130, 220, 38, 30, { s: B, w: 1 }) + person(51, 168, 0.8) + person(100, 168, 0.8) + person(149, 168, 0.8) + p('M30 150Q50 120 70 140M130 140Q150 120 170 150', { s: B, w: 1, o: 0.6 }) + p('M20 270L180 270', { s: B }); },
    world: function () { var s = ''; s += '<ellipse cx="100" cy="166" rx="54" ry="86" fill="none" stroke="' + G + '" stroke-width="1.4"/>' + '<ellipse cx="100" cy="166" rx="44" ry="76" fill="none" stroke="' + G + '" stroke-width="0.8" opacity="0.5"/>'; s += person(100, 140, 1); s += p('M80 200Q100 188 120 200', { s: B }); s += c(40, 86, 6, { s: B }) + c(160, 86, 6, { s: B }) + c(40, 246, 6, { s: B }) + c(160, 246, 6, { s: B }); s += star(40, 86, 5, 5) + star(160, 86, 5, 5); return s; }
  };

  function frontSVG(card) {
    var motif = (MOTIF[card.id] || function () { return ''; })();
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 340">' +
      '<rect width="200" height="340" rx="10" fill="' + N + '"/>' +
      '<rect x="7" y="7" width="186" height="326" rx="6" fill="' + N2 + '" stroke="' + G + '" stroke-width="1"/>' +
      '<rect x="13" y="13" width="174" height="314" rx="3" fill="none" stroke="' + G + '" stroke-width="0.5" opacity="0.6"/>' +
      '<text x="100" y="38" text-anchor="middle" font-family="Georgia,\'Times New Roman\',serif" font-size="13" letter-spacing="4" fill="' + G + '">' + ROMAN[card.number] + '</text>' +
      '<line x1="70" y1="48" x2="130" y2="48" stroke="' + G + '" stroke-width="0.6" opacity="0.7"/>' +
      '<g transform="translate(0,6)">' + motif + '</g>' +
      '<line x1="60" y1="298" x2="140" y2="298" stroke="' + G + '" stroke-width="0.6" opacity="0.7"/>' +
      '<text x="100" y="314" text-anchor="middle" font-family="Georgia,\'Times New Roman\',serif" font-size="10.5" letter-spacing="2.2" fill="' + W + '">' + card.en.toUpperCase() + '</text>' +
      '</svg>';
    return svg;
  }

  function backSVG() {
    var s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 340">' +
      '<rect width="200" height="340" rx="10" fill="' + N + '"/>' +
      '<rect x="7" y="7" width="186" height="326" rx="6" fill="#0e1630" stroke="' + G + '" stroke-width="1"/>' +
      '<rect x="13" y="13" width="174" height="314" rx="3" fill="none" stroke="' + G + '" stroke-width="0.5" opacity="0.6"/>';
    // 菱形格子
    for (var i = -6; i <= 14; i++) {
      s += '<line x1="' + (i * 24) + '" y1="13" x2="' + (i * 24 + 170) + '" y2="327" stroke="' + G + '" stroke-width="0.4" opacity="0.22"/>';
      s += '<line x1="' + (i * 24 + 170) + '" y1="13" x2="' + (i * 24) + '" y2="327" stroke="' + G + '" stroke-width="0.4" opacity="0.22"/>';
    }
    s += '<circle cx="100" cy="170" r="42" fill="#0b1020" stroke="' + G + '" stroke-width="1"/>' +
      '<circle cx="100" cy="170" r="36" fill="none" stroke="' + G + '" stroke-width="0.5" opacity="0.7"/>' +
      '<text x="100" y="177" text-anchor="middle" font-family="Georgia,\'Times New Roman\',serif" font-size="20" letter-spacing="5" fill="' + G + '">NYX</text>' +
      '<text x="102" y="177" text-anchor="middle" font-size="0"></text>' +
      '</svg>';
    return s;
  }

  function toURI(svg) { return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg); }
  var cache = {};
  window.NYX_ART = {
    front: function (card) { return cache[card.id] || (cache[card.id] = toURI(frontSVG(card))); },
    back: function () { return cache.__back || (cache.__back = toURI(backSVG())); }
  };
})();
